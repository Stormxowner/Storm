<h1 align="center"><b>『Revor Musíc』 </b></h1>

<p align="center">
    <br><b>يدعم تشغيل الموسيقي والفديو داخل المحادثات الصوتية</b><br>
</p>
<p align="center">
    <a href="https://www.python.org/" alt="اللغة المستخدمة"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>
</p>
## 🧪الحصول علي جلسة البيوجرام:

[![جلسة بيوجرام](https://img.shields.io/badge/repl.it-generateString-yellowgreen)](https://replit.com/@levinalab/StringSession#main.py) ``RevorTeam``

## 🎭 حقوق السورس
<p align="center">
  <img src="https://telegra.ph/file/4c7636b9c50116387d9f6.jpg">
</p>

## ✨ المميزات
- يدعم تشغيل الفديو والموسيقي في المحادثة
- يدعم المحادثات المتعددة
- قائمه الانتظار مدعم
- تخطي وتوقف واستمرار مدعم
- يدعم تحميل فديو وصوت 
- يدعم البحث انلاين
- يدعم البحث المباشر من يوتيوب
- يدعم البث الحي من يوتيوب
- يدعم التحكم عن طريق الازرار
- يدعم التحكم بالصوت
- يدعم الدخول التلقائي للبوت المساعد
- تحديث مباشر

## 🛠 الاوامر:
| الاوامر | الوصف |
| ------ | ------ |
| `/mplay (اسم الاغنيه)` | تشغيل أغنية من يوتيوب |
| `/vplay (اسم الفديو)` | لتشغيل فديو من يوتيوب |
| `/vstream (لينك البث)` | لتشغيل بث حي فديو|
| `/pause` | لايقاف التشغيل ادمن فقط |
| `/resume` | لاستكمال التشغيل ادمن فقط |
| `/skip` | لتخطي الاغنيه ادمن فقط |
| `/stop` | لانهاء العرض ادمن فقط |
| `/vmute` | لكتم البوت المساعد |
| `/vunmute` | لالغاء كتم البوت المساعد |
| `/volume 1/200` | للتحكم في الصوت  |
| `/playlist` | لرؤية قائمة الاغاني |
| `/song (اسم الاغنيه)` | لتحميل اغنية |
| `/video (اسم الفديو)` | لتحميل فديو |
| `/userbotjoin` | لدعوة البوت المساعد |
| `/userbotleave` | لمغادرة البوت المساعد |
| `/leaveall` | خروج جميع المجموعات للمطور فقط |
| `/update` | تحديث البوت للمطور فقط |
| `/restart` | للمطور فقط اعاده تشغيل البوت |
| `/clean` | مسح جميع الملفات |
| `/rmd` | مسح جميع الملفات المحمله |
## التنصيب علي هيوركا 💜
من أسهل طرق تشغيل البوت ولكن مدتها 22 يوم فقط 

[![تشغيل](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Dev3yad/revormusic)






### قناة التحديثات والدعم 🎑
<a href="https://t.me/revorb0t"><img src="https://img.shields.io/badge/Join-Group%20Support-blue.svg?style=for-the-badge&logo=Telegram"></a> <a href="https://t.me/kkv65r"><img src="https://img.shields.io/badge/Join-Updates%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>



### تم تطوير السورس بواسطة
<a href="https://t.me/u660p"><img src="https://img.shields.io/badge/Dev%20Sonic-blue.svg?style=for-the-badge&logo=Aboelmagd"></a> <a href="https://t.me/yyybd"><img src="https://img.shields.io/badge/Dev%20Ayad-blue.svg?style=for-the-badge&logo=Ayad"></a> <a href="https://t.me/MahmoudM2"><img src="https://img.shields.io/badge/Dev%20Mahmoud-blue.svg?style=for-the-badge&logo=Mahmoud"></a>
